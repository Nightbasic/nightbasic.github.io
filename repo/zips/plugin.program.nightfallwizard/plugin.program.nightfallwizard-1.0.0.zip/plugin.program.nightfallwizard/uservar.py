import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://nightfall.lol/wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://nightfall.lol/wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
