import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://r33.ca/wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://r33.ca/wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
